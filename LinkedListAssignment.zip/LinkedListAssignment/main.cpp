//
//  main.cpp
//  LinkedListAssignment
//
//  Created by Josh on 8/13/21.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
